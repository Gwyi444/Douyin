import joblib
import pandas as pd


model = joblib.load('build_model\like_model.joblib')
scaler = joblib.load('build_model\like_scaler.joblib')


def predict_likes(input_data):
    features = [
        input_data['duration'],
        input_data['collect'],
        input_data['comment'],
        input_data['shar'],
        input_data['fans'],
        input_data['interaction_rate'],
        input_data['hour'],
    ]
    features_names = ['视频时长','收藏数量','评论数量','分享数量','粉丝数量','互动率','发布小时']

    df = pd.DataFrame([features], columns=features_names)

    scaler_features = scaler.transform(df)
    prediction = model.predict(scaler_features)
    return round(prediction[0], 0)

example_data = {
    'duration': 180,
    'collect': 1500,
    'comment': 800,
    'shar': 400,
    'fans': 25000,
    'interaction_rate': 0.25,
    'hour': 19
}

print(predict_likes(example_data))