class Config:
    DB_HOST = 'localhost'
    DB_NAME = 'dy_django_analysis'
    DB_USER = 'root'
    DB_PASSWORD = '123456'
    DB_PORT = 3306
    api_key = 'bce-v3/ALTAK-JZGMgULsrR56XiCCxIKTB/be245eeefbe13526d63c9d31f8d1019a44218957'
    appid = 'app-hAO25Hx8'