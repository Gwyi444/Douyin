import re
from collections import Counter
from django.core.paginator import Paginator
from django.http import HttpResponseRedirect, JsonResponse, HttpResponse
from django.shortcuts import render, redirect
import json
import pandas as pd


import util
from video.models import User, VideoData, CommentData
from django.contrib import messages

# Create your views here.

def login(request):
    if request.method == 'POST':
        uname = request.POST.get("username")
        password = request.POST.get("password")
        try:
            user = User.objects.get(username=uname, password=password)
            request.session['username'] = uname
            request.session['uid'] = user.id
            return redirect('/home/index/')
        except:
            return render(request, "login.html", {"error_msg": "用户名或密码错误，请重新输入"})

    else:
        return render(request, 'login.html')

def register(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        password = request.POST.get('password')
        try:
            User.objects.get(username=uname)
            messages.error(request, '用户已存在')
            return HttpResponseRedirect('/home/register/')
        except:
            User.objects.create(username=uname, password=password)
            messages.success(request, '注册成功')
            return HttpResponseRedirect("/home/login/")
    else:
        return render(request, 'register.html')

def index(request):
    maxData = VideoData.objects.count()
    maxLike = VideoData.objects.order_by('-likeCount').first().likeCount
    maxComment = VideoData.objects.order_by('-commentCount').first().commentCount
    maxCollect = VideoData.objects.order_by('-collectCount').first().collectCount
    sql = 'select * from part2'
    res = util.query(sql)
    xData = [i[2] for i in res]
    xData1 = [i[0] for i in res]
    xData2 = [i[1] for i in res]
    xData3 = [i[3] for i in res]
    page = request.GET.get("page", 1)
    per_page = 10
    all_data = VideoData.objects.all().order_by("-id")
    paginator = Paginator(all_data, per_page)
    page_obj = paginator.get_page(page)
    content = {
        'maxData': maxData,
        'maxLike': maxLike,
        'maxComment': maxComment,
        'maxCollect': maxCollect,
        'xData': xData,
        'xData1': xData1,
        'xData2': xData2,
        'xData3': xData3,
        'page_obj': page_obj,
    }
    return render(request, 'index.html', context=content)

def comment_list(request):
    page = request.GET.get('page', 1)

    comment_info = CommentData.objects.all()
    per_page = 10
    paginator = Paginator(comment_info, per_page)
    page_obj = paginator.get_page(page)

    content = {
        'page_obj': page_obj,
    }

    return render(request, 'comment_list.html', context=content)


def part1(requests):
    sql = 'select * from part1'
    res = util.query(sql)
    result = []
    for i in res:
        result.append({'name':i[0], 'value':i[1]})
    return render(requests, 'part1.html', {'result':result})


def part2(requests):
    sql = 'select * from part3'
    res = util.query(sql)
    result = []
    for i in res:
        result.append({"value": i[1], "name": i[0]})
    sql2 = 'select * from part4'
    res2 = util.query(sql2)
    name_list = [i[0] for i in res2]
    value_list = [i[1] for i in res2]
    content = {
        "result": result,
        'name_list': name_list,
        'value_list':value_list
    }
    return render(requests, 'part2.html', content)



def part3(request):
    sql = 'select * from part5'
    res = util.query(sql)
    value_list1 = [i[0] for i in res]
    value_list2 = [i[1] for i in res]
    name_list3 = [i[2] for i in res]
    df = pd.read_csv('./data/npl_result.csv')
    chinese_word_pattern = re.compile(r'^[\u4e00-\u9fff]+$')
    all_words = []
    for segmented_text in df['segmented']:
        if isinstance(segmented_text, str):
            words = segmented_text.strip().split()
            chinese_words = [word for word in words if chinese_word_pattern.fullmatch(word)]
            all_words.extend(chinese_words)

    word_counts = Counter(all_words)

    word_counts_list = [{"name": word, "value": count}for word, count in word_counts.items()]

    comtent ={
        'name_list': name_list3,
        'value_list1': value_list1,
        'value_list2': value_list2,
        'word_counts_list':word_counts_list
    }

    return render(request, 'part3.html', comtent)


def part4(request):
    df = pd.read_csv('./data/npl_result.csv')
    bins = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
    labels = ['0-0.1', '0.1-0.2', '0.2-0.3','0.3-0.4',
              '0.4-0.5','0.5-0.6', '0.6-0.7','0.7-0.8', '0.8-0.9',
              '0.9-1']
    df['score_group'] = pd.cut(df['scores'].astype(float),bins=bins,labels=labels)
    score_counts = df['score_group'].value_counts().sort_index()
    name_list = []
    value_list = []
    for k,v in score_counts.items():
        name_list.append(k)
        value_list.append(v)
    scoresDict = {"积极":0, "消极":0, "中性":0}
    for i in df['scores']:
        if float(i) < 0.5:
            scoresDict['消极'] += 1
        elif float(i) == 0.5:
            scoresDict['中性'] += 1
        elif float(i) >0.5 and float(i)<1.0:
            scoresDict["积极"] += 1
    result = []
    for k,v in scoresDict.items():
        result.append({"value":v, "name":k})
    content = {
        'name_list':name_list,
        'value_list':value_list,
        'result':result
    }
    print(content)
    return render(request,'part4.html',content)


def part5(request):
    return render(request, 'part5.html')
def part6(request):
    return render(request, 'part6.html')
from farecast import predict_likes
from django.http import JsonResponse  # 确保已导入


def predict(request):
    if request.method == 'POST':
        try:
            def get_float_val(name, default=0):
                val = request.POST.get(name)
                if val is None or val == '':
                    return default
                return float(val)
            def get_int_val(name, default=0):
                val = request.POST.get(name)
                if val is None or val == '':
                    return default
                return int(val)
            interaction_rate = request.POST.get('interaction_rate') or request.POST.get('interaction-rate')
            if interaction_rate is None or interaction_rate == '':
                interaction_rate = 0
            input_data = {
                'duration': get_float_val('duration'),
                'collect': get_float_val('collect'),
                'comment': get_float_val('comment'),
                'shar': get_float_val('shar'),  # 如果用户没填，默认为0
                'fans': get_float_val('fans'),
                'interaction_rate': float(interaction_rate),
                'hour': get_int_val('hour', 12),
            }
            print("处理后的输入数据:", input_data)
            prediction = predict_likes(input_data)
            print(f"预测结果: {prediction}")
            return render(request, 'predict.html', {'preResult': prediction, 'inputData':input_data,'showResult':True})
        except Exception as e:
            print(f"预测错误: {e}")
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
    else:
        return render(request, 'predict.html')



from Get_qianfan import analyze_single_video


def get_ai(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            print("接收到的数据:", data)

            # 构建视频数据字典（确保键名一致）
            video_data = {
                '粉丝数量': int(data.get('fans', 0)),
                '发布时间': data.get('publish_date', ''),
                '视频描述': data.get('description', ''),
                '视频时长': data.get('duration', ''),
                '点赞数': int(data.get('likes', 0)),
                '收藏数': int(data.get('favorites', 0)),
                '评论数': int(data.get('comments', 0)),
                '分享数': int(data.get('shares', 0)),
            }
            print("构建的视频数据:", video_data)
            analysis_focus = data.get('analysis_focus', '')
            result = analyze_single_video(video_data, analysis_focus)
            return JsonResponse(result)
        except json.JSONDecodeError as e:
            return JsonResponse({'error': f'JSON解析错误: {str(e)}'}, status=400)
        except Exception as e:
            print(f"分析错误: {e}")
            return JsonResponse({'error': f'分析失败: {str(e)}'}, status=500)
    else:
        return render(request, 'get_ai.html')


def changeInfo(request):
    uid = request.session.get('uid')

    # ✅ 加这个判断
    if not uid:
        js_code = """
        <script>
            alert("请先登录");
            window.location.href = "/home/login/";
        </script>
        """
        return HttpResponse(js_code)

    userInfo = User.objects.get(id=uid)
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        oldPwd = request.POST.get('oldPwd')
        newPwd = request.POST.get('newPwd')
        chkPwd = request.POST.get('chkPwd')
        user = User.objects.get(id=user_id)
        if newPwd != chkPwd:
            js_code = """
            <script>
                alert("两次输入密码不一致");
                window.location.href = "/home/changeInfo/";
            </script>
            """
            return HttpResponse(js_code)
        elif oldPwd != user.password:
            js_code = """
            <script>
                alert("原始密码错误");
                window.location.href = "/home/changeInfo/";
            </script>
            """
            return HttpResponse(js_code)
        else:
            user.password = newPwd
            user.save()
            js_code = """
            <script>
                alert("修改成功");
                window.location.href = "/home/changeInfo/";
            </script>
            """
            return HttpResponse(js_code)
    else:
        return render(request, 'changeInfo.html', {'userInfo': userInfo})


def Logout(request):
    request.session.clear()
    return render('login')