import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import numpy as np

df = pd.read_csv('../data/data.csv')


time_column = df.iloc[:, 5]
print(time_column)
seconds = []

for time in time_column:
    try:
        minutes, seconds_val = map(int, time.split(':'))
        total_seconds = minutes * 60 + seconds_val
    except:
        total_seconds = np.nan
    seconds.append(total_seconds)

df['视频时长'] = seconds
df['互动率'] = (df['点赞数量']+ df['评论数量']+ df['分享数量']) / df['粉丝数量']
df['发布时间'] = pd.to_datetime(df['发表时间'])
df['发布小时'] = df['发布时间'].dt.hour

features = df[['视频时长','收藏数量','评论数量','分享数量','粉丝数量','互动率','发布小时']]

target = df['点赞数量']

features = features.replace([np.inf, -np.inf], np.nan)  # 无穷大转空值
features = features.dropna()
target = target.loc[features.index]
scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

X_train,X_test,y_train,y_test = train_test_split(features_scaled, target, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

#评估模型
y_pred = model.predict(X_test)
print(f'模型R2为：{r2_score(y_test, y_pred): .2f}')

joblib.dump(model, 'like_model.joblib')
joblib.dump(scaler,'like_scaler.joblib')