from datetime import datetime
import time
from config import Config
from openai import OpenAI


def analyze_single_video(video_data, analysis_focus=None):
    AI_CONFIG = {
        'api_key': Config.api_key,
        'base_url': 'https://qianfan.baidubce.com/v2',
        'appid': Config.appid
    }

    client = OpenAI(
        base_url=AI_CONFIG['base_url'],
        api_key=AI_CONFIG['api_key'],
        default_headers={"appid": AI_CONFIG['appid']},
    )

    # 解析发布时间
    try:
        publish_data = datetime.strptime(video_data['发布时间'], "%Y.%m.%d")
        days_since_publish = (datetime.now() - publish_data).days
        days_info = f"已发布{days_since_publish}天"
    except:
        days_since_publish = 0
        days_info = '发布时间数据异常'

    # 解析视频时长
    try:
        duration_str = str(video_data['视频时长'])
        if ':' in duration_str:
            minutes, seconds = map(int, duration_str.split(":"))
            video_duration = minutes * 60 + seconds
        elif '.' in duration_str:
            parts = duration_str.split(".")
            minutes = int(parts[0])
            seconds = int(parts[1]) if len(parts) > 1 else 0
            video_duration = minutes * 60 + seconds
        else:
            video_duration = int(float(duration_str))
    except Exception as e:
        print(f"时长解析错误: {e}")
        video_duration = 0

    # 计算关键指标
    try:
        fans = int(video_data.get('粉丝数量', 0))
        likes = int(video_data.get('点赞数', 0))
        comments = int(video_data.get('评论数', 0))
        shares = int(video_data.get('分享数', 0))
        favorites = int(video_data.get('收藏数', 0))
        description = video_data.get('视频描述', '')

        if fans > 0:
            like_rate = round((likes / fans) * 100, 2)
            interaction_rate = round(((likes + comments + shares) / fans) * 100, 2)
        else:
            like_rate = 0
            interaction_rate = 0

        print(f"=== 指标计算 ===")
        print(f"粉丝: {fans}, 点赞: {likes}, 评论: {comments}, 分享: {shares}")
        print(f"点赞率: {like_rate}%, 互动率: {interaction_rate}%")

    except Exception as e:
        print("指标异常:", e)
        return {"error": f"数据处理错误: {str(e)}"}

    prompt = f"""
    你好，我是视频内容智能助手。请分析以下视频信息数据，并提供优化建议。

        === 视频基础信息 ===
        - **粉丝数量**: {fans}
        - **发表时间**: {days_info}
        - **视频描述**: {description}
        - **视频时长**: {video_duration}秒
        - **点赞数**: {likes}
        - **收藏数**: {favorites}
        - **评论数**: {comments}
        - **分享数**: {shares}

        === 关键指标 ===
        - **点赞率**: {like_rate}%
        - **互动率**: {interaction_rate}%

        === 分析重点 ===
        {analysis_focus if analysis_focus else "1. 找出该视频表现优异/不足的指标，提供内容优化建议，建议发布时间调整（如有数据）"}

        请按照以下结构返回分析结果：
        === 表现评估 ===
        [分析点赞/评论/分享等指标的优劣]

        === 优化建议 ===
        1. [内容方向调整建议]
        2. [互动设计建议(如提问、投票等)]
        3. [标签/话题优化建议]
    """

    # 重试机制
    max_retries = 3
    for attempt in range(max_retries):
        try:
            messages = [
                {"role": 'system', "content": "你是一个专业的短视频数据分析师，擅长从数据中发现优化机会。"},
                {"role": 'user', "content": prompt}
            ]

            response = client.chat.completions.create(
                model="ernie-4.5-turbo-128k",
                messages=messages,
                temperature=0.8,
                top_p=0.8,
            )

            result_text = response.choices[0].message.content
            print(f"AI返回内容长度: {len(result_text)}")

            # 检查返回内容是否有效
            if len(result_text) > 50 and (
                    '点赞' in result_text or '视频' in result_text or '优化' in result_text or '表现' in result_text):
                return {
                    "analysis": result_text,
                    "metrics": {
                        "like_rate": like_rate,
                        "interaction_rate": interaction_rate,
                        "duration": video_duration,
                        "days_since_publish": days_since_publish
                    }
                }
            else:
                print(f"第{attempt + 1}次返回内容异常，重试中...")
                if attempt < max_retries - 1:
                    time.sleep(1)

        except Exception as e:
            print(f"第{attempt + 1}次调用失败: {e}")
            if attempt < max_retries - 1:
                time.sleep(1)

    # AI分析失败，使用本地备用分析
    print("AI分析失败，使用本地备用分析")
    fallback_analysis = get_fallback_analysis(fans, likes, comments, shares, favorites, description,
                                              like_rate, interaction_rate, video_duration, days_info, analysis_focus)
    return {
        "analysis": fallback_analysis,
        "metrics": {
            "like_rate": like_rate,
            "interaction_rate": interaction_rate,
            "duration": video_duration,
            "days_since_publish": days_since_publish
        }
    }


def get_fallback_analysis(fans, likes, comments, shares, favorites, description,
                          like_rate, interaction_rate, video_duration, days_info, analysis_focus):
    """当AI分析失败时，生成本地备用分析"""

    # 评估点赞率
    if like_rate > 8:
        like_status = "优秀，远超平均水平"
    elif like_rate > 5:
        like_status = "良好，高于平均水平"
    elif like_rate > 2:
        like_status = "一般，处于平均水平"
    else:
        like_status = "较低，需要提升"

    # 评估互动率
    if interaction_rate > 10:
        interaction_status = "优秀，用户参与度高"
    elif interaction_rate > 6:
        interaction_status = "良好，用户互动积极"
    elif interaction_rate > 3:
        interaction_status = "一般，互动有待提升"
    else:
        interaction_status = "较低，需要加强互动引导"

    return f"""=== 表现评估 ===

📊 关键数据分析：
• 视频表现：获得 {likes} 个点赞、{comments} 条评论、{shares} 次分享
• 点赞率：{like_rate}% - {like_status}
• 互动率：{interaction_rate}% - {interaction_status}
• 收藏数：{favorites} 次收藏
• 视频时长：{video_duration}秒
• {days_info}

📈 粉丝基础：{fans} 人

=== 优化建议 ===

1. 📝 内容优化：
   • {'当前互动率较好，继续保持内容质量' if interaction_rate > 5 else '提升视频内容质量，增加趣味性和价值性'}
   • 视频时长{video_duration}秒{'，时长适中' if 15 <= video_duration <= 60 else '，建议控制在15-60秒之间以提高完播率' if video_duration > 60 else '，可以适当延长以传递更多信息'}

2. 💬 互动引导：
   • 在视频开头设置悬念或问题，引导用户评论
   • 结尾添加明确的互动指令，如"你觉得呢？评论区告诉我"
   • {'当前互动表现不错，继续保持互动设计' if interaction_rate > 6 else '增加投票、话题讨论等互动环节'}

3. 🏷️ 标签优化：
   • 使用3-5个精准的长尾标签
   • 结合热门话题和垂直领域标签
   • 参考同类爆款视频的标签策略

4. ⏰ 发布策略：
   • {days_info}
   • {'建议在用户活跃高峰时段（12:00-14:00或18:00-22:00）发布' if days_since_publish == 0 else '分析历史数据，找出最佳发布时间段' if 'days_since_publish' in locals() else ''}
   • 保持稳定的更新频率，培养用户观看习惯

5. 🎯 受众定位：
   • 分析粉丝画像，针对目标受众优化内容
   • 关注评论区用户反馈，及时调整内容方向
   • {analysis_focus if analysis_focus else '持续关注数据变化，迭代优化策略'}"""