import pandas as pd
import jieba
from snownlp import SnowNLP

def nlpdemont(df):
    with open('stopwords.txt', 'r', encoding='utf-8') as f:
        stopwords = [line.strip() for line in f]


    scores = []
    seagmented_comments = []
    for comment in df['评论内容']:
        comment = str(comment)

        words = jieba.cut(comment)

        filter_words = [word for word in words if word not in stopwords or word in ["不","没","非常","特别"]]


        filter_text = ''.join(filter_words)
        seagmented_comments.append(''.join(filter_words))

        if not filter_text.strip():
            scores.append(0.5)
        else:
            s = SnowNLP(filter_text)
            scores.append(s.sentiments)


    df['scores'] = scores
    df['segmented'] = seagmented_comments

    df.to_csv('npl_result.csv',index=False)






if __name__ == "__main__":
    df = pd.read_csv('comment_data.csv')
    nlpdemont(df)