import requests
import time
import csv
import pandas as pd
headers = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "zh-CN,zh;q=0.9",
    "bd-ticket-guard-client-data": "eyJ0c19zaWduIjoidHMuMi5jZTk2OWYzODUzNmFjN2Y0YWVjOGQwZTkyYzA0MDk4ODU4ZjFiZTRmZGFlOTkwMGZhZGFiNmYyMzA2YjE1ZmIyYzRmYmU4N2QyMzE5Y2YwNTMxODYyNGNlZGExNDkxMWNhNDA2ZGVkYmViZWRkYjJlMzBmY2U4ZDRmYTAyNTc1ZCIsInJlcV9jb250ZW50IjoidGlja2V0LHBhdGgsdGltZXN0YW1wIiwicmVxX3NpZ24iOiJXRW4yakQrR3NlRkRiczRWVlVRQ2Yrb2JYOUpPSVlNSHBrUlZscE1aaXFNPSIsInRpbWVzdGFtcCI6MTc3NjI2NTI1Nn0=",
    "bd-ticket-guard-ree-public-key": "BJLO0HGXJbGUcgJkuk4Id4Whq9eBGPU+JcGjr1M5ClvRiNw0a5yRNFpxW1ixArnt/+qs0qOLxpG7TqXmflGbvRo=",
    "bd-ticket-guard-version": "2",
    "bd-ticket-guard-web-sign-type": "1",
    "bd-ticket-guard-web-version": "2",
    "priority": "u=1, i",
    "referer": "https://www.douyin.com/search/%E5%93%AA%E5%90%922?modal_id=7544149063982746937&type=video",
    "sec-ch-ua": "\"Microsoft Edge\";v=\"147\", \"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"147\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "uifid": "3b6adaced0a588dab6f51c731af48a99e86229cd7fa27db4535ff73b415f88b56ac291ec58fb86970e4296769c4e531955357b3057d8901a94c83e11c5ab96d8bfd44ee72c1bc9baaa3577b47a46ad69847ab58e049580767d6be0b608a0c23381ff9c5d8430eaa153558710d16def98031c891d98870c572093181147666f87806b4224494ac4a7156f0a3d055ab60e185781c09be2b378be8832433927bdb8",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}
cookies = {
    "enter_pc_once": "1",
    "UIFID_TEMP": "3b6adaced0a588dab6f51c731af48a99e86229cd7fa27db4535ff73b415f88b58251c4620e4187676da4f50b6427f3e585809a12791ba5cf7412d39c66a7f98b98d272d4a28a5ff18abcb9f43cc52a7f",
    "s_v_web_id": "verify_mnzqisf5_18FQYofc_8pky_4Sx2_AQbe_33v5S2XL8Zl1",
    "dy_swidth": "1536",
    "dy_sheight": "864",
    "strategyABtestKey": "%221776238474.458%22",
    "fpk1": "U2FsdGVkX19K8zlfsB5p/dAoeeohwrN2l96LKB0H7qoGotoPEVqyaJwe/WkntnURRcnZKI3be9OQB2JR1UAthw==",
    "fpk2": "4238b62bcd3c1a9c24ccf656e6ace824",
    "passport_csrf_token": "3b2fd14af340cb30097beda7d127d348",
    "passport_csrf_token_default": "3b2fd14af340cb30097beda7d127d348",
    "bd_ticket_guard_client_web_domain": "2",
    "UIFID": "3b6adaced0a588dab6f51c731af48a99e86229cd7fa27db4535ff73b415f88b56ac291ec58fb86970e4296769c4e531955357b3057d8901a94c83e11c5ab96d8bfd44ee72c1bc9baaa3577b47a46ad69847ab58e049580767d6be0b608a0c23381ff9c5d8430eaa153558710d16def98031c891d98870c572093181147666f87806b4224494ac4a7156f0a3d055ab60e185781c09be2b378be8832433927bdb8",
    "passport_mfa_token": "Cje3IDK0QTuH%2BkrEY2DysLw49madUoJJ7qJcliVHsE7zNb9tdu8AElUPfQivRTr8wf58oICY6KGIGkoKPAAAAAAAAAAAAABQTs1DFEQoC41IiHyMwzkU%2BRoj92meCGU1gPI6jn4zMCYKlDIGGGglK0pSHDpMMgOkGRC28I4OGPax0WwgAiIBA1hHpFE%3D",
    "d_ticket": "1340eb27d02c914063aa854cbba6a20fffa4c",
    "passport_assist_user": "CkH6dtw4XxTBH4w1k44mwQbC2XO-LuN3WippNukkB19i23TDycXOU8rHXJ-Gv88a2BWCVMGhk62e7C_bWSzZSaqa0xpKCjwAAAAAAAAAAAAAUE5EBWhvo8-MKQaOISS4iBoTdTZXVF4ODwEG0rq2v6V1vfE5ikj3h0mWurWninDMlqwQ__CODhiJr9ZUIAEiAQOaQBeZ",
    "n_mh": "y5nu1elAxSKvb7j0QieVOuPJse489b4BN7UORWXhfBs",
    "passport_auth_status": "4dc5a9600f15a249e1b2ef37851576e1%2C",
    "passport_auth_status_ss": "4dc5a9600f15a249e1b2ef37851576e1%2C",
    "sid_guard": "d40ed4b97b708919b39dfbd260661cba%7C1776238549%7C5184000%7CSun%2C+14-Jun-2026+07%3A35%3A49+GMT",
    "uid_tt": "b1883c9a387cb330dcc696a83df105b2",
    "uid_tt_ss": "b1883c9a387cb330dcc696a83df105b2",
    "sid_tt": "d40ed4b97b708919b39dfbd260661cba",
    "sessionid": "d40ed4b97b708919b39dfbd260661cba",
    "sessionid_ss": "d40ed4b97b708919b39dfbd260661cba",
    "session_tlb_tag": "sttt%7C18%7C1A7UuXtwiRmznfvSYGYcuv_________IzuLvuH4TN7LjNygmTlfhVLxDbRzQxdVeaUHtiEvtbgw%3D",
    "is_staff_user": "false",
    "has_biz_token": "false",
    "sid_ucp_v1": "1.0.0-KDEwMjk0ZTdiODZhYzdjMjIwYWRmYjc0MWNlM2I4NTI5ZGIwYTM1NTUKIQj408CBjfTaBRDV__zOBhjvMSAMMMuHtOgFOAJA8QdIBBoCbGYiIGQ0MGVkNGI5N2I3MDg5MTliMzlkZmJkMjYwNjYxY2Jh",
    "ssid_ucp_v1": "1.0.0-KDEwMjk0ZTdiODZhYzdjMjIwYWRmYjc0MWNlM2I4NTI5ZGIwYTM1NTUKIQj408CBjfTaBRDV__zOBhjvMSAMMMuHtOgFOAJA8QdIBBoCbGYiIGQ0MGVkNGI5N2I3MDg5MTliMzlkZmJkMjYwNjYxY2Jh",
    "_bd_ticket_crypt_cookie": "fae31ca59ce155bcea93ed41d338695e",
    "__security_mc_1_s_sdk_sign_data_key_web_protect": "59a46712-4b2c-95ed",
    "__security_mc_1_s_sdk_cert_key": "7010d7c6-4910-a505",
    "__security_mc_1_s_sdk_crypt_sdk": "1e42aec2-4661-945e",
    "__security_server_data_status": "1",
    "login_time": "1776238550900",
    "DiscoverFeedExposedAd": "%7B%7D",
    "ttwid": "1%7Clja9_j3bxD3pM7UBpzWnD70kO4gIo9q9rULWsxW1ABk%7C1776238554%7Cd05df6240b2a6f2701fcb62e9e4041e59865ac1b8f059a8ff0c6c561d8e86032",
    "is_dash_user": "1",
    "volume_info": "%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Afalse%2C%22volume%22%3A0.5%7D",
    "publish_badge_show_info": "%221%2C0%2C0%2C1776238554868%22",
    "SEARCH_RESULT_LIST_TYPE": "%22single%22",
    "download_guide": "%223%2F20260415%2F0%22",
    "stream_recommend_feed_params": "%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1536%2C%5C%22screen_height%5C%22%3A864%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A12%2C%5C%22device_memory%5C%22%3A32%2C%5C%22downlink%5C%22%3A3.7%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A100%7D%22",
    "my_rd": "2",
    "stream_player_status_params": "%22%7B%5C%22is_auto_play%5C%22%3A0%2C%5C%22is_full_screen%5C%22%3A0%2C%5C%22is_full_webscreen%5C%22%3A0%2C%5C%22is_mute%5C%22%3A0%2C%5C%22is_speed%5C%22%3A1%2C%5C%22is_visible%5C%22%3A0%7D%22",
    "PhoneResumeUidCacheV1": "%7B%223214563175574008%22%3A%7B%22time%22%3A1776252650514%2C%22noClick%22%3A1%7D%7D",
    "__ac_nonce": "069dfa7a500d8bf9e9ef9",
    "__ac_signature": "_02B4Z6wo00f01TTxxLgAAIDAThgwXFHOe-U00cAAACTm35",
    "csrf_session_id": "52bdf33e9953c0bfd5d1dad0c471b917",
    "SelfTabRedDotControl": "%5B%7B%22id%22%3A%227443294244770416675%22%2C%22u%22%3A58%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227489412399603943487%22%2C%22u%22%3A86%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227169919485166487564%22%2C%22u%22%3A80%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227552940651961124899%22%2C%22u%22%3A62%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227543606604571904046%22%2C%22u%22%3A44%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227454934363139278874%22%2C%22u%22%3A68%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227592223642147096628%22%2C%22u%22%3A14%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227506852418143914018%22%2C%22u%22%3A5%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227188534283034691641%22%2C%22u%22%3A759%2C%22c%22%3A0%7D%5D",
    "FOLLOW_LIVE_POINT_INFO": "%22MS4wLjABAAAAujTFRLTsenIMN9MhjLoLlWxQCV1wnhgi-03z8sVPm4bH3ILS7CgE6sdisJY1S1v3%2F1776268800000%2F0%2F0%2F1776265732314%22",
    "FOLLOW_NUMBER_YELLOW_POINT_INFO": "%22MS4wLjABAAAAujTFRLTsenIMN9MhjLoLlWxQCV1wnhgi-03z8sVPm4bH3ILS7CgE6sdisJY1S1v3%2F1776268800000%2F0%2F0%2F1776266332315%22",
    "sdk_source_info": "7e276470716a68645a606960273f276364697660272927676c715a6d6069756077273f276364697660272927666d776a68605a607d71606b766c6a6b5a7666776c7571273f275e58272927666a6b766a69605a696c6061273f27636469766027292762696a6764695a7364776c6467696076273f275e582729277672715a646971273f2763646976602729277f6b5a666475273f2763646976602729276d6a6e5a6b6a716c273f2763646976602729276c6b6f5a7f6367273f27636469766027292771273f2730333034313430333733323234272927676c715a75776a716a666a69273f2763646976602778",
    "bit_env": "2MMcJKIfDvi-oh2Anr3A9fP9UILAG3DIGaDAMePO6WCglnJFNBdDcmXUYjcbDXNWmv8rvMYfgqeqFyJawoF1AsKjJfLmREGXIk7Ze8ykvz1BWTtNxInxnEDoC04tfdfQFNZcRy6_gsIJp0U_L_6toOdEgh4rJnecwp1qxuYB86PasS5LRtinYt9gTSM8D7ne4NWbc3Vov-Wxv4Z9N2wPLr0-dzGwYdvgsc86llWQT4DrX55Nce7aEw5RkwJA4K0XJ_EbD1ynbMBUnIBbD8cntZRcaK4zey0b8HNSQDww46zxCcICUKwMMoAdOohYrjO-muqTPHdESmJSp3z6G-iUOrJfE2O3KFa2TS88-bCsOWq8kn4pjDLYazUFMytaVSWIPHdgVQaWwtgeos4zy1p8PlPG8QEff2Bv4M0o4fhJuoSg64fd9VA9-GInSNfunk-9XeFOiHSeT5Zo4PW6OU35f-oFhDu5CpAOJ611XpvddOlE0yAyvt43XTdzO9rwshae9lpnogSzSLSwdW7gaPD89DKXHBxHLB3OmRzaKTM_ijM%3D",
    "gulu_source_res": "eyJwX2luIjoiYzA3ZDQzMmJmM2E3YmU5Mjc0ZjBmODA2OGQwZjQ3N2M1Y2I2Mzc2NjNlZTdhOTBiMjlhZWNjZWE3YzQxMjgxYSJ9",
    "passport_auth_mix_state": "97m43f3lgi5re1ukg27u903n35wuxtwq19pzn4yazj0kdhd2",
    "IsDouyinActive": "true",
    "home_can_add_dy_2_desktop": "%221%22",
    "bd_ticket_guard_client_data": "eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCSkxPMEhHWEpiR1VjZ0prdWs0SWQ0V2hxOWVCR1BVK0pjR2pyMU01Q2x2UmlOdzBhNXlSTkZweFcxaXhBcm50LytxczBxT0x4cEc3VHFYbWZsR2J2Um89IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoyfQ%3D%3D",
    "biz_trace_id": "d5962a66",
    "bd_ticket_guard_client_data_v2": "eyJyZWVfcHVibGljX2tleSI6IkJKTE8wSEdYSmJHVWNnSmt1azRJZDRXaHE5ZUJHUFUrSmNHanIxTTVDbHZSaU53MGE1eVJORnB4VzFpeEFybnQvK3FzMHFPTHhwRzdUcVhtZmxHYnZSbz0iLCJ0c19zaWduIjoidHMuMi5jZTk2OWYzODUzNmFjN2Y0YWVjOGQwZTkyYzA0MDk4ODU4ZjFiZTRmZGFlOTkwMGZhZGFiNmYyMzA2YjE1ZmIyYzRmYmU4N2QyMzE5Y2YwNTMxODYyNGNlZGExNDkxMWNhNDA2ZGVkYmViZWRkYjJlMzBmY2U4ZDRmYTAyNTc1ZCIsInJlcV9jb250ZW50Ijoic2VjX3RzIiwicmVxX3NpZ24iOiIzWVI1aTg2OTBGWjlxaDl2RU1SajNQWWtyamVHUVNHOVFVYmdZdHpGQjdrPSIsInNlY190cyI6IiNQbzVPbS9JUU5Eb0hkdEgyNGZvM0tTdWZjUGUvSnV2c011ZC83YmZVLzdHNW04QVRVS2N1Vjk5aDQ5U2EifQ%3D%3D",
    "odin_tt": "4c483efaf1040d898b8eee4b7b64b2d29ccbfd98fa8501405d6c20095f0ac490f548b3528157ffad0ccc2d1ec182c2b27c5eb24a3a340f1e9924d414da92927d"
}
def get_time(ctime):
    time_local = time.localtime(ctime)
    time_formal = time.strftime("%Y.%m.%d", time_local)
    return str(time_formal)

def get_json(awme_id, cursor):
    url = "https://www.douyin.com/aweme/v1/web/comment/list/"
    params = {
        'aid': 6383,
        "aweme_id": awme_id,
        "cursor": cursor,
        "count": 10,
        "platform": "PC",
        "downlink": "10",
        "uifid": "3b6adaced0a588dab6f51c731af48a99e86229cd7fa27db4535ff73b415f88b56ac291ec58fb86970e4296769c4e531955357b3057d8901a94c83e11c5ab96d8bfd44ee72c1bc9baaa3577b47a46ad69847ab58e049580767d6be0b608a0c23381ff9c5d8430eaa153558710d16def98031c891d98870c572093181147666f87806b4224494ac4a7156f0a3d055ab60e185781c09be2b378be8832433927bdb8",
        "msToken": "ZdSMovTf541nrCn5PMzd0ZACunEYA-EaryzlBPvmPTWv9e_PFsL7fL8c4ntetabF_Ju9e4ACA8PiFIP4B4p-ycuA7kzeiWtL-zlAV5HOYALLlPnnuOiIOPCwIDRPTgzvFPVOLBenReluGU-4oGkF0xgNIkC2O6-izUz67Ewvx8OFuYDJAVKujg==",
        "a_bogus": "Oy0jkHU7YoAnOdMSYCint6/lI8DMNPuye-T2RqHlSPqba7tbtYNYmaaQJoq8wQj2AuBkkF57tE0lYExb847zZFrkwmpkuuvWRTd5nWsogqZvTBJ291RPC4SEFi-YWA4PKQVrE3i110ULZLcfNN9PlZK9yAtjBuY8TNa6pNUUHxg-gakYVIKfCPgW"
    }
    response = requests.get(url, headers=headers, cookies=cookies, params=params)

    return response.json()

def parseData(feed, aweme_id):
    ip_label = feed.get('ip_label')
    try:
        username = feed['user']['nickname']
    except:
        username = '暂无用户名'
    comment_dict = {
        '用户id': feed['user']['uid'],
        '用户名': username,
        '评论时间': get_time(feed['create_time']),
        'ip地址': ip_label,
        '评论内容': feed.get('text', ''),
        '点赞数量': feed.get('digg_count', ''),
        'aweme_id': aweme_id
    }
    print(comment_dict)
    writer.writerow(comment_dict)




def spider_comment(aweme_id):
    cursor = 0
    page = 1
    while True:
        response = get_json(aweme_id, cursor)
        try:
            if response['comments'] is None:
                break
            feeds = response['comments']
            for feed in feeds:
                parseData(feed, aweme_id)
            if response['has_more'] == 0:
                break
            cursor += 20
            page+=1
            if page > 20:
                break
        except Exception as e:
            print(f'爬取失败,错误: {e}')
            continue
if __name__ == "__main__":
    header = ['用户id', '用户名',
              '评论时间', 'ip地址', '评论内容', '点赞数量', 'aweme_id']
    f = open('comment_data.csv', 'a', encoding='utf-8', newline='')
    writer = csv.DictWriter(f, header)
    writer.writeheader()
    df = pd.read_csv('data.csv')
    for index,row in df.iterrows():
        spider_comment(row['视频id'])