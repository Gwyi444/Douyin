import pandas as pd
import pymysql
from config import Config
import numpy as np
conn = pymysql.connect(
    host=Config.DB_HOST,
    user=Config.DB_USER,
    password=Config.DB_PASSWORD,
    db=Config.DB_NAME,
    port=Config.DB_PORT
)
cursor = conn.cursor()

def save_video_info():
    sql = ('insert into videodata (username,fansCount,description,' \
            'aweme_id,publishTime,duration,likeCount,collectCount,commentCount,shareCount,downloadCount) ' \
           'values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)')
    df = pd.read_csv('data.csv')
    df = df.replace([np.nan, np.inf, -np.inf], None)
    df = df.where(pd.notnull(df), None)
    for index,row in df.iterrows():
        cursor.execute(sql, tuple(row))
    conn.commit()
    cursor.close()
    conn.close()


def save_comment_info():
    sql = ('insert into commentdata(userid,username,commentTime,userIP ,content,likeCount,aweme_id)'\
           'values (%s,%s,%s,%s,%s,%s,%s)')
    df = pd.read_csv('comment_data.csv')
    df = df.replace([np.nan, np.inf, -np.inf], None)
    df = df.where(pd.notnull(df), None)
    df = df.dropna(subset=['评论内容'])
    for index, row in df.iterrows():
        cursor.execute(sql, tuple(row))
    conn.commit()
    cursor.close()
    conn.close()








# save_video_info()
save_comment_info()