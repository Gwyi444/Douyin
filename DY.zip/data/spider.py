import random
import time
import csv
import requests

headers = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "zh-CN,zh;q=0.9",
    "priority": "u=1, i",
    "referer": "https://www.douyin.com/jingxuan/search/python?aid=fd363fbb-2fb7-44f6-8707-7a5f69798f35&type=general",
    "sec-ch-ua": "\"Chromium\";v=\"148\", \"Microsoft Edge\";v=\"148\", \"Not/A)Brand\";v=\"99\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "uifid": "ee69abbd54cdddb154b01110285f038c0f724c22a9fa6fa6ff8c47d6ab1f845c0223df740227bfcd48045913c4fbed8f9402d7766a4ac3fe241268bfc6eaf5d8c4e39236e30a3a759ea5e1a9b76d283341c186a56629c7dc050fb9de9931e3e5de167581062eb586146f96ca1b85e2fbfdc60016945a31211ea030efc4fd6f467053fe0b9b628e595afa9ae2c4b8d7b76e8acf09f77e7d9a3218a7e5a61a99e6",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0"
}
cookies = {
    "bd_ticket_guard_client_web_domain": "2",
    "passport_csrf_token": "a94fc1d427b1e05a4dad484159de6574",
    "passport_csrf_token_default": "a94fc1d427b1e05a4dad484159de6574",
    "SEARCH_RESULT_LIST_TYPE": "%22single%22",
    "x-web-secsdk-uid": "bd6530b2-16d7-4e0c-94e9-4e90f3ebadaa",
    "csrf_session_id": "390900f6825024a45c2bbdd64e59bb76",
    "SEARCH_UN_LOGIN_PV_CURR_DAY": "%7B%22date%22%3A1778489786097%2C%22count%22%3A1%7D",
    "fpk1": "U2FsdGVkX19AhvI9u2w95+U91p/Fa+t8t6IWX1L+ReeC9LB0ED0CVDsMk26Ezv2N0gS2GZ5FzgyTzX4+YFRWPQ==",
    "fpk2": "d782f8d891caba24ff6aeba315180cac",
    "s_v_web_id": "verify_mp0yweu4_0bEJKFw7_cJMj_4AYU_9TVS_x8qnBzNXhGH4",
    "passport_mfa_token": "Cjeye03xbq2gRDky8ggqAuBXhLI3tB9Q4HYUKLJ1C3m8d6AH%2Fn9Scq9hIKTGMJkzcW4uvq3rhlK3GkoKPAAAAAAAAAAAAABQaPAinv8%2FTCeDIUx%2FP%2FwNAj9w6RMSRPL8llYB9DROF7p21ZyvnIkH7L7EQ2JK8LLD0hDAlZEOGPax0WwgAiIBA28bTvM%3D",
    "d_ticket": "5db7186e159280cb1093724eb520ec81a7588",
    "passport_assist_user": "CkHzFbMI28v2-6tp8u-2VtXqkpw10zWuSCtS_jxtkpHxhQkn3pPUe09qmYVgvCwaJO8TFkTD4LIFs3wUTKEFitgJehpKCjwAAAAAAAAAAAAAUGhBhhb_XWG2r9NLiNUsyD6n3UiRrBJYtO5XmGn5Gwivu2qJBnQAS-Miildx8jN1AY4QwZWRDhiJr9ZUIAEiAQOK1HgC",
    "n_mh": "y5nu1elAxSKvb7j0QieVOuPJse489b4BN7UORWXhfBs",
    "sid_guard": "68a7067b81bce96ee42f9b0b611d31f7%7C1778489859%7C5184000%7CFri%2C+10-Jul-2026+08%3A57%3A39+GMT",
    "uid_tt": "bb59b35c5537dcc8a16784db7c5df91b",
    "uid_tt_ss": "bb59b35c5537dcc8a16784db7c5df91b",
    "sid_tt": "68a7067b81bce96ee42f9b0b611d31f7",
    "sessionid": "68a7067b81bce96ee42f9b0b611d31f7",
    "sessionid_ss": "68a7067b81bce96ee42f9b0b611d31f7",
    "session_tlb_tag": "sttt%7C17%7CaKcGe4G86W7kL5sLYR0x9__________E0T2VjMY17c0Kh11hakiZwrSvvhZ8hudzZ3i5N8EyQyo%3D",
    "is_staff_user": "false",
    "has_biz_token": "false",
    "sid_ucp_v1": "1.0.0-KDFiZjhkMjEyMGFiZjgzZjY2MWEzODk1MTc0YWM3ZTBkNGI5YzQyMWEKIQj408CBjfTaBRCDtIbQBhjvMSAMMMuHtOgFOAdA9AdIBBoCbHEiIDY4YTcwNjdiODFiY2U5NmVlNDJmOWIwYjYxMWQzMWY3",
    "ssid_ucp_v1": "1.0.0-KDFiZjhkMjEyMGFiZjgzZjY2MWEzODk1MTc0YWM3ZTBkNGI5YzQyMWEKIQj408CBjfTaBRCDtIbQBhjvMSAMMMuHtOgFOAdA9AdIBBoCbHEiIDY4YTcwNjdiODFiY2U5NmVlNDJmOWIwYjYxMWQzMWY3",
    "_bd_ticket_crypt_cookie": "959d5125db5b1a7686616fa0db500aba",
    "__security_mc_1_s_sdk_sign_data_key_web_protect": "aad772e2-4157-95de",
    "__security_mc_1_s_sdk_cert_key": "6e3e011b-4c4d-8a2f",
    "__security_mc_1_s_sdk_crypt_sdk": "84870017-4d8a-8a0e",
    "__security_server_data_status": "1",
    "login_time": "1778489861785",
    "__ac_signature": "_02B4Z6wo00f01qxE1WQAAIDD1q0hg5XvfHKsZNHAAMEc21",
    "SelfTabRedDotControl": "%5B%7B%22id%22%3A%227543606604571904046%22%2C%22u%22%3A47%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227489412399603943487%22%2C%22u%22%3A89%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227606155526367381556%22%2C%22u%22%3A22%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227552940651961124899%22%2C%22u%22%3A65%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227443294244770416675%22%2C%22u%22%3A62%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227359237545974040610%22%2C%22u%22%3A11%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227169919485166487564%22%2C%22u%22%3A81%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227592223642147096628%22%2C%22u%22%3A17%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227628144506142984228%22%2C%22u%22%3A13%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227454934363139278874%22%2C%22u%22%3A68%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227506852418143914018%22%2C%22u%22%3A5%2C%22c%22%3A0%7D%2C%7B%22id%22%3A%227188534283034691641%22%2C%22u%22%3A759%2C%22c%22%3A0%7D%5D",
    "is_dash_user": "1",
    "publish_badge_show_info": "%220%2C0%2C0%2C1778489873354%22",
    "volume_info": "%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Afalse%2C%22volume%22%3A0.5%7D",
    "playRecommendGuideTagCount": "1",
    "totalRecommendGuideTagCount": "1",
    "FOLLOW_NUMBER_YELLOW_POINT_INFO": "%22MS4wLjABAAAAujTFRLTsenIMN9MhjLoLlWxQCV1wnhgi-03z8sVPm4bH3ILS7CgE6sdisJY1S1v3%2F1778515200000%2F0%2F1778489994971%2F0%22",
    "download_guide": "%223%2F20260511%2F0%22",
    "enter_pc_once": "1",
    "UIFID": "ee69abbd54cdddb154b01110285f038c0f724c22a9fa6fa6ff8c47d6ab1f845c0223df740227bfcd48045913c4fbed8f9402d7766a4ac3fe241268bfc6eaf5d8c4e39236e30a3a759ea5e1a9b76d283341c186a56629c7dc050fb9de9931e3e5de167581062eb586146f96ca1b85e2fbfdc60016945a31211ea030efc4fd6f467053fe0b9b628e595afa9ae2c4b8d7b76e8acf09f77e7d9a3218a7e5a61a99e6",
    "douyin.com": "",
    "device_web_cpu_core": "12",
    "device_web_memory_size": "32",
    "architecture": "amd64",
    "is_support_rtm_web_ts": "1",
    "dy_swidth": "1536",
    "dy_sheight": "864",
    "stream_recommend_feed_params": "%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1536%2C%5C%22screen_height%5C%22%3A864%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A12%2C%5C%22device_memory%5C%22%3A32%2C%5C%22downlink%5C%22%3A10%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A50%7D%22",
    "FOLLOW_LIVE_POINT_INFO": "%22MS4wLjABAAAAujTFRLTsenIMN9MhjLoLlWxQCV1wnhgi-03z8sVPm4bH3ILS7CgE6sdisJY1S1v3%2F1778515200000%2F0%2F1778491663440%2F0%22",
    "bd_ticket_guard_client_data": "eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCSEd4Tkt4WnFUSDJFZXlHdm9IQkZtT1pLMGFiNGJtb0IwYTc5aEVOV2tMNmorVldpUksvN2VkaTRvdG1FWlZKRzJha1RqNHJsaU9OSWwvamtYUGptYkE9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoyfQ%3D%3D",
    "strategyABtestKey": "%221778491665.155%22",
    "home_can_add_dy_2_desktop": "%221%22",
    "odin_tt": "cc01798a24a8725040eba87869feb222246303f4d8d82b6764e21e56331598cfabce5991f3c3296dd05e44d0200444fd7b5ffbf30cefff577d699501c869da5c26b2812ee3af7bea3246074a31f4ebe2",
    "ttwid": "1%7Ctl6ZIVzquGlsbWIDhr5GVmuAlKFsZtLa7hhkSk1dQp0%7C1778491665%7C38c36afe1c283c4372db11e67cfb362ac9294a6ca8b95211746d0f3e00dbb8f8",
    "sdk_source_info": "7e276470716a68645a606960273f276364697660272927676c715a6d6069756077273f276364697660272927666d776a68605a607d71606b766c6a6b5a7666776c7571273f275e58272927666a6b766a69605a696c6061273f27636469766027292762696a6764695a7364776c6467696076273f275e582729277672715a646971273f2763646976602729277f6b5a666475273f2763646976602729276d6a6e5a6b6a716c273f2763646976602729276c6b6f5a7f6367273f27636469766027292771273f273c3c36323333343c313d323234272927676c715a75776a716a666a69273f2763646976602778",
    "bit_env": "CN3Cew-zUrBF8rolOfAJc8p7Sr5J-JACtsPd8pVmDoe4Jtn2Ex6r-pfvBsjyOdeINxqKdPlt8Ai2YJkw5DDuV5am2Twp4Yx3Xl7Pv2f3mhdHnYkjGisxRbxDF48nKO9ZMLUJibC0YIZwnObOKI_e4fOW4NgYXhkybqNc9c-rCGD9jzjVQ_h8Cs1oRdykIi1qNZv7UajS5FG4cMR88YuIATUSE3iM2eAuirc1mq9W8ZxUv-2nK7cAUSvj0QrXU5vIzijXKjYBeu1d8z7dj7lnPa7fEifCCT-sLWIXXHH0DPO218KiE2uRdL95xPbsMoWXsj17UkpyiWLfWlIXrJVduFPgYJdtSj8M5FjOlcfVeDfxiKJlD8e9KmFM41MIiENuvvVaDsn478Su8_YNpHFgexkAAr5DhNWqdvx18souZLlZYVDQRw3_DW7bi7tTG1nK6Vb8C_ojoqRyFu2MrISEtZgpKB1p9MUtaeZ0kU6R4Wgffu2uyXFczEJGOjTLcaR11ZRFOWOopLQLlIS5-TF0_RCH4zdR67N_W8bnBlR2VjE%3D",
    "gulu_source_res": "eyJwX2luIjoiMDM5NTkxYTlhNTA5ZWZjZTcyNGNiODBkODlkYjA1MzhiZWI3MTY2MGUxYTI2YWRiY2Q4MjNlYjY3M2Y5NmZjNCJ9",
    "passport_auth_mix_state": "1wijvczh0cxmrat4e7mx9e7hzs83amxytwn0nfgwgh4gmw7q",
    "biz_trace_id": "98c86c81",
    "bd_ticket_guard_client_data_v2": "eyJyZWVfcHVibGljX2tleSI6IkJIR3hOS3hacVRIMkVleUd2b0hCRm1PWkswYWI0Ym1vQjBhNzloRU5Xa0w2aitWV2lSSy83ZWRpNG90bUVaVkpHMmFrVGo0cmxpT05JbC9qa1hQam1iQT0iLCJ0c19zaWduIjoidHMuMi5hYmY1ZjQ0ZjNjYWNmOTY4ZDc1NDA1ZjE4ZmM0OWNhNWYxY2ZiNjcxODVlMjJjZWViYmRmZmQ3MmI3YjhiZWUzYzRmYmU4N2QyMzE5Y2YwNTMxODYyNGNlZGExNDkxMWNhNDA2ZGVkYmViZWRkYjJlMzBmY2U4ZDRmYTAyNTc1ZCIsInJlcV9jb250ZW50Ijoic2VjX3RzIiwicmVxX3NpZ24iOiJkenpidmlURTV1MUtFRTBkRDJnVFhhN2QxZ1pEZUhteitZU0lEQTF3cXlRPSIsInNlY190cyI6IiNTUWExblFGSUNaaWZ2VWdrSDBJcVdJZHVHZ0hvRkMrTW5ib3NlbHlXRzQ5K3NWUDI0ejFhdURaSmI0aEwifQ%3D%3D",
    "IsDouyinActive": "true"
}
url = "https://www.douyin.com/aweme/v1/web/search/item/"

def get_time(ctime):
    time_local = time.localtime(ctime)
    time_formal = time.strftime("%Y.%m.%d", time_local)
    return str(time_formal)

def get_json(keyword,offset,count):
    params = {
        "aid": 6383,
        "channel": "channel_pc_web",
        "search_channel": "aweme_general",
        "keyword": keyword,
        "offset": offset,
        "is_filter_search": 0,
        "publish_time": 0,
        "sort_type": 0,
        "update_version_code": 170400,
        "search_id": "20260511172808D1E2EE9E7237A1FFE1B5",
        "count": count,
        "need_filter_settings": 0,
        }
    time.sleep(random.randint(1,5))
    response = requests.get(url, headers=headers, cookies=cookies, params=params)
    return response.json()


def parseData(response):
    global video_dict
    minutes = response['video']['duration'] // 1000 // 60
    seconds = response['video']['duration'] // 1000 % 60
    video_dict = {
        '用户名': response['author']['nickname'].strip(),
        '粉丝数量': response['author']['follower_count'],
        '视频描述': response['desc'],
        '视频id': response['aweme_id'],
        '发表时间': get_time(response['create_time']),
        '视频时长': "{:02d}:{:02d}".format(minutes,seconds),
        '点赞数量': response['statistics']['digg_count'],
        '收藏数量': response['statistics']['collect_count'],
        '评论数量': response['statistics']['comment_count'],
        '分享数量': response['statistics']['share_count'],
        '下载数量': response['statistics']['download_count']
    }

    print(video_dict)
    writer.writerow(video_dict)


def search(keyword):
    offset = 0
    count = 16
    while True:
        response = get_json(keyword, offset, count)
        feeds = response['data']
        for feed in feeds:
            if 'aweme_info' in feed:
                parseData(feed['aweme_info'])

            else:
                continue
        if response['has_more'] == 0:
            break
        offset += count
        count = 10
if __name__ == "__main__":
    header = ['用户名', '粉丝数量','视频描述', '视频id',
              '发表时间','视频时长','点赞数量','收藏数量','评论数量', '分享数量', '下载数量']
    f = open('data.csv', 'a', encoding='utf-8', newline='')
    writer = csv.DictWriter(f, header)
    writer.writeheader()
    keyword = 'python'
    search(keyword)